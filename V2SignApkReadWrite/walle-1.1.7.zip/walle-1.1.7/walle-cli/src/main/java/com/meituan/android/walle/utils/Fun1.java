package com.meituan.android.walle.utils;


public interface Fun1<T, R> {
    R apply(T v);
}
