package com.meituan.android.walle.commands;

/**
 * Created by chentong on 21/11/2016.
 */

public interface IWalleCommand {
    void parse();
}
