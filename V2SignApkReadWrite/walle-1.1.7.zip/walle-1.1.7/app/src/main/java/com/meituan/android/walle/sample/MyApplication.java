
package com.meituan.android.walle.sample;

import android.app.Application;

public class MyApplication extends Application {

}
